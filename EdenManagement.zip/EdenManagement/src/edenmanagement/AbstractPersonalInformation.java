package edenmanagement;

public abstract class AbstractPersonalInformation {
    protected String name;
    protected String surname;
    protected int age;
    protected String gender;
    protected String phoneNumber;
    // Other fields...

    // Constructor
    public AbstractPersonalInformation( String surname, int age, String gender, String phoneNumber) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
    }

    // toString() method
    @Override
    public String toString() {
        return '}' + "AbstractPatient{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", phoneNumber='" + phoneNumber + '\'';
             }
}