package edenmanagement;
public interface AppointmentInformation {
    String getDoctor();
    String getService();
    String getDate();
    String getTime();
}
    
