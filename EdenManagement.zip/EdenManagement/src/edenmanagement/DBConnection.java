package edenmanagement;
import java.sql.Connection;
import java.awt.HeadlessException;
import java.sql.SQLException;
import java.sql.Driver; 
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class DBConnection {

public static Connection connect(){
    Connection con = null;
    
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/edenmanagement?useSSL=false&serverTimezone=UTC&zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
        JOptionPane.showMessageDialog(null , "Database Connected");
    }
    
    catch(HeadlessException | ClassNotFoundException |SQLException e){
        System.out.println(e);
        
    }
    return con;
   
     }

}
