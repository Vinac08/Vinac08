package edenmanagement;
public abstract class AbstractAppointment implements AppointmentInformation {
    protected String doctor;
    protected String service;
    protected String date;
    protected String time;

    // Constructor
    public AbstractAppointment(String doctor, String service, String date, String time) {
        this.doctor = doctor;
        this.service = service;
        this.date = date;
        this.time = time;
    }

    // Implementing the interface methods
    @Override
    public String getDoctor() {
        return doctor;
    }

    @Override
    public String getService() {
        return service;
    }

    @Override
    public String getDate() {
        return date;
    }

    @Override
    public String getTime() {
        return time;
    }
}
