
package edenmanagement;
public abstract class AbstractMedicalHistory implements MedicalHistory {
    protected String hereditaryConditions;
    protected String allergies;
    protected String smokingStatus;
    protected String surgeries;
    protected String mentalHealthHistory;

    @Override
    public String getHereditaryConditions() {
        return hereditaryConditions;
    }

    @Override
    public String getAllergies() {
        return allergies;
    }

    @Override
    public String getSmokingStatus() {
        return smokingStatus;
    }

    @Override
    public String getSurgeries() {
        return surgeries;
    }

    @Override
    public String getMentalHealthHistory() {
        return mentalHealthHistory;
    }
}

