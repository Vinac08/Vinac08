
package edenmanagement;

public interface MedicalHistory {
    String getHereditaryConditions();
    String getAllergies();
    String getSmokingStatus();
    String getSurgeries();
    String getMentalHealthHistory();
    
}
