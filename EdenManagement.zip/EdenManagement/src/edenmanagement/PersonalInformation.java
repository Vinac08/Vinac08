
package edenmanagement;
public interface PersonalInformation {
    String getName();
    String getSurname();
    int getAge();
    String getGender();
    String getPhoneNumber();
    String getAddress();
    String getNationality();
}
   

